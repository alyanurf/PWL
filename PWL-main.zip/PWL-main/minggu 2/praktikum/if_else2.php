<?php
$user = "masaboe";
$pass = "123"
if ($user == "masaboe" && $pass == "123") {
echo "Login Berhasil";
} else {
echo "Login Gagal";
}
?>

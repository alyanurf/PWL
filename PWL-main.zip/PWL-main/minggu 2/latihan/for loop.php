
<html>
<body>

<?php  
for ($x = 1; $x <= 5; $x++) {
	for ($y = 1; $y <= $x; $y++) {
  		echo $x ;
		}
        echo "<br>";
        }
?>  

</body>
</html>


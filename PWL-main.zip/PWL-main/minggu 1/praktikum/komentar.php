<?
/* Komentar tidak akan tercetak di layar
Komentar baris kedua
*/
// komentar satu baris
# komentar satu baris
echo "Muncul dilayar...";
?>

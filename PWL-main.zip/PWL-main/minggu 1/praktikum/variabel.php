<?php
$nim = "A11.2010.08132";
$nama = 'Sutrisno';
echo "NIM : " . $nim . "<br>";
echo "Nama : $nama";
?>
